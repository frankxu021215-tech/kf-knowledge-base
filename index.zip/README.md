# K&F CONCEPT 客服知识库 - 在线同步版部署指南

## 效果预览

改造后的在线版本支持：
- **实时数据同步**：任何人打开网站，数据自动从云端加载，所有人看到的是同一份知识库
- **房间号隔离**：不同团队可以使用不同房间号，数据互不干扰
- **本地数据迁移**：可将原版本积累的知识库一键上传到云端
- **完全免费**：使用 Firebase 免费版 + GitHub Pages/Netlify 免费托管

---

## 第一步：注册 Firebase 项目（约 5 分钟）

Firebase 是 Google 提供的免费云数据库，用于存储和同步知识库数据。

1. 打开 https://firebase.google.com/
2. 点击右上角 **"Go to console"**，用 Google/Gmail 账号登录
3. 点击 **"Create a project"**
4. 输入项目名称（如 `kfconcept-kb`），点击 **Continue**
5. 关闭 **"Enable Google Analytics"** 开关（不需要），点击 **Create project**
6. 等待项目创建完成，点击 **Continue**

### 1.1 创建 Realtime Database

1. 左侧菜单找到 **"Realtime Database"**，点击进入
2. 点击 **"Create Database"**
3. 数据库位置选择 **"us-central1"**（美国中部），点击 **Next**
4. **安全规则**选择 **"Start in test mode"**（测试模式，允许读写），点击 **Enable**

### 1.2 获取 API 配置信息

1. 点击左侧齿轮图标 **"Project settings"**
2. 在 **"General"** 标签页下方，找到 **"Your apps"** 区域
3. 点击 **"</>"**（Web 图标）
4. 输入应用昵称（如 `kf-kb-web`），点击 **Register app**
5. 复制下面这段配置代码（类似下面这样）：

```javascript
const firebaseConfig = {
  apiKey: "AIzaSyABC123xxxxxxxx",
  authDomain: "kfconcept-kb.firebaseapp.com",
  databaseURL: "https://kfconcept-kb-default-rtdb.firebaseio.com",
  projectId: "kfconcept-kb",
  storageBucket: "kfconcept-kb.appspot.com",
  messagingSenderId: "123456789",
  appId: "1:123456789:web:abcdef123456"
};
```

**把这个配置记下来，下一步需要粘贴到代码中。**

---

## 第二步：修改代码中的 Firebase 配置（约 2 分钟）

1. 用文本编辑器（如记事本、VS Code）打开 `index.html`
2. 找到第 551 行附近的这段代码：

```javascript
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  databaseURL: "https://YOUR_PROJECT_ID-default-rtdb.firebaseio.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT_ID.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID"
};
```

3. 把上一步复制的真实配置**完整替换**进去
4. 保存文件

---

## 第三步：部署到 GitHub Pages（免费网址，约 3 分钟）

### 3.1 注册 GitHub 账号

1. 打开 https://github.com/
2. 点击 **"Sign up"**，用邮箱注册（免费）

### 3.2 创建仓库并上传文件

**方式 A：网页上传（最简单，推荐）**

1. 登录 GitHub，点击右上角 **"+"** → **"New repository"**
2. 仓库名称填 `kf-knowledge-base`（可自定义）
3. 选择 **Public**（公开）
4. 点击 **"Create repository"**
5. 在新页面中找到 **"uploading an existing file"**，点击该链接
6. 将 `index.html` 文件拖拽到上传区域
7. 点击页面最下方的 **"Commit changes"**

**方式 B：Git 命令行（如果你会用 Git）**

```bash
git init
git add index.html
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/你的用户名/kf-knowledge-base.git
git push -u origin main
```

### 3.3 启用 GitHub Pages

1. 在仓库页面，点击上方 **"Settings"**
2. 左侧菜单点击 **"Pages"**
3. 在 **"Source"** 区域，分支选择 **"main"**，文件夹选择 **"/ (root)"**
4. 点击 **"Save"**
5. 等待 1-2 分钟，页面会显示你的网址：`https://你的用户名.github.io/kf-knowledge-base/`

**把这个链接发给任何同事，打开即可看到实时同步的知识库！**

---

## 第四步：（可选）绑定自己的 .com 域名

如果你希望网址是 `www.yourcompany.com` 而不是 `xxx.github.io`：

1. 在阿里云/腾讯云/GoDaddy 购买域名（约 60-100 元/年）
2. 在域名管理后台添加一条 **CNAME 记录**：
   - 主机记录：`www` 或 `@`
   - 记录值：`你的用户名.github.io`
3. 回到 GitHub Pages 设置页面，在 **"Custom domain"** 处输入你的域名，点击 **Save**
4. 等待 DNS 生效（通常几分钟到几小时）

---

## 第五步：数据迁移（将旧版本数据上传到云端）

如果你之前使用本地版本积累了很多知识库数据：

1. 用浏览器打开新部署的在线版本网址
2. 登录管理员账号（默认 Frank / Frank1215）
3. 点击顶部导航栏的 **"☁️ 迁移本地数据到云端"** 按钮
4. 确认后，本地数据将上传到当前房间，所有访问该房间的人都能看到

> **房间号说明**：顶部导航栏显示当前房间号（如 "房间: default"）。点击可以切换房间。不同房间的数据完全隔离，相当于不同的知识库。你可以给不同平台/团队分配不同房间号。

---

## 常见问题

**Q：Firebase 免费版够用吗？**
> 完全够用。免费版支持最多 100 个同时在线连接，存储空间 1GB，每月 10GB 下载流量。对于客服团队的知识库来说绰绰有余。

**Q：数据安全吗？**
> 当前配置使用 Firebase 测试模式（公开读写）。建议正式上线后修改安全规则，限制只有你的团队能访问。具体方法见 Firebase 文档。

**Q：可以多人同时编辑吗？**
> 可以。Firebase Realtime Database 支持多人同时读写，数据会实时同步到所有人的屏幕上。

**Q：如果以后不用了，数据怎么导出？**
> 和原来一样，点击顶部 **"导出备份"** 按钮即可下载 JSON 格式的完整备份。

---

## 技术支持

如有问题，可以将 `index.html` 文件发回给我，我可以帮你排查。
